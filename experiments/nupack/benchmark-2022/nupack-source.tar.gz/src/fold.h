/*
 * $Id$
 * 
 * Copyright (C) 2010 Kengo Sato
 *
 * This file is part of IPknot.
 *
 * IPknot is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * IPknot is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with IPknot.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef __INC_FOLD_H__
#define __INC_FOLD_H__

#include <string>
#include <vector>
#include <list>
#include <memory>
#include <stdexcept>

const float DEFAULT_THRESHOLD = 0.001;
typedef unsigned int uint;
using VI = std::vector<int>;
using VSVF = std::vector<std::vector<std::pair<uint, float>>>;

// The base class for calculating base-pairing probabilities of an individual sequence
class BPEngineSeq
{
public:
  BPEngineSeq() { }
  virtual ~BPEngineSeq() {}

  virtual void calculate_posterior(const std::string& seq,
                                   std::vector<float>& bp, std::vector<int>& offset) const = 0;
  virtual auto calculate_posterior(const std::string& seq, float th=DEFAULT_THRESHOLD) const 
    -> std::vector<std::vector<std::pair<uint, float>>>
  {
    throw std::runtime_error("not supported yet");
  }

  virtual void calculate_posterior(const std::string& seq, const std::string& paren,
                                   std::vector<float>& bp, std::vector<int>& offset) const = 0;
  virtual auto calculate_posterior(const std::string& seq, const std::string& paren, float th=DEFAULT_THRESHOLD) const
    -> std::vector<std::vector<std::pair<uint, float>>>
  {
    throw std::runtime_error("not supported yet");
  }
  
  // Update base-pairing probability matrix method
  void update_bpm(uint pk_level, const std::string& seq, const VI& bpseq, const VI& plevel, VSVF& sbp) const;
  void update_bpm(uint pk_level, const std::string& seq, const VI& bpseq, const VI& plevel, std::vector<float>& bp, VI& offset) const;
  
  // Factory method
  static std::unique_ptr<BPEngineSeq> build(const char* model, const char* param, uint beam_size=100, uint n_th=1, const std::string& mxfold2_config="", int mxfold2_gpu=-1);
};

// The base class for calculating base-pairing probabilities of aligned sequences
class BPEngineAln
{
public:
  BPEngineAln() { }
  virtual ~BPEngineAln() {}

  virtual void calculate_posterior(const std::list<std::string>& aln,
                                   std::vector<float>& bp, std::vector<int>& offset) const = 0;
  virtual auto calculate_posterior(const std::list<std::string>& aln, float th=DEFAULT_THRESHOLD) const 
    -> std::vector<std::vector<std::pair<uint, float>>>
  {
    throw std::runtime_error("not supported yet");
  }

  virtual void calculate_posterior(const std::list<std::string>& aln, const std::string& paren,
                                   std::vector<float>& bp, std::vector<int>& offset) const = 0;
  virtual auto calculate_posterior(const std::list<std::string>& aln, const std::string& paren, float th=DEFAULT_THRESHOLD) const
    -> std::vector<std::vector<std::pair<uint, float>>>
  {
    throw std::runtime_error("not supported yet");
  }
  
  // Update base-pairing probability matrix method
  void update_bpm(uint pk_level, const std::list<std::string>& aln, const VI& bpseq, const VI& plevel, VSVF& sbp) const;
  void update_bpm(uint pk_level, const std::list<std::string>& aln, const VI& bpseq, const VI& plevel, std::vector<float>& bp, VI& offset) const;
  
  // Factory method
  static std::unique_ptr<BPEngineAln> build(const std::vector<std::string>& model, const char* param, uint beam_size=100, uint n_th=1, const std::string& mxfold2_config="", int mxfold2_gpu=-1);
};

class CONTRAfoldModel : public BPEngineSeq
{
public:
  CONTRAfoldModel() : BPEngineSeq() { }

  void calculate_posterior(const std::string& seq, std::vector<float>& bp, std::vector<int>& offset) const override;
  auto calculate_posterior(const std::string& seq, float th=DEFAULT_THRESHOLD) const 
    -> std::vector<std::vector<std::pair<uint, float>>> override;

  void calculate_posterior(const std::string& seq, const std::string& paren,
                           std::vector<float>& bp, std::vector<int>& offset) const override;
  auto calculate_posterior(const std::string& seq, const std::string& paren, float th=DEFAULT_THRESHOLD) const
    -> std::vector<std::vector<std::pair<uint, float>>> override;
};

class RNAfoldModel : public BPEngineSeq
{
public:
  RNAfoldModel(const char* param);
  
  void calculate_posterior(const std::string& seq, std::vector<float>& bp, std::vector<int>& offset) const override;
  auto calculate_posterior(const std::string& seq, float th=DEFAULT_THRESHOLD) const 
    -> std::vector<std::vector<std::pair<uint, float>>> override;
    
  void calculate_posterior(const std::string& seq, const std::string& paren,
                           std::vector<float>& bp, std::vector<int>& offset) const override;
  auto calculate_posterior(const std::string& seq, const std::string& paren, float th=DEFAULT_THRESHOLD) const
    -> std::vector<std::vector<std::pair<uint, float>>> override;
};

class NupackModel : public BPEngineSeq
{
public:
  //NupackModel(int model) : BPEngineSeq(), model_(model), param_(NULL) { }
  NupackModel(const char* param) : BPEngineSeq(), param_(param) { }
  
  void calculate_posterior(const std::string& seq, std::vector<float>& bp, std::vector<int>& offset) const override;
  auto calculate_posterior(const std::string& seq, float th=DEFAULT_THRESHOLD) const 
    -> std::vector<std::vector<std::pair<uint, float>>> override;

  void calculate_posterior(const std::string& seq, const std::string& paren,
                           std::vector<float>& bp, std::vector<int>& offset) const override
  {
    throw std::runtime_error("not supported yet");
  }
//  auto calculate_posterior(const std::string& seq, const std::string& paren, float th=DEFAULT_THRESHOLD) const
//    -> std::vector<std::vector<std::pair<uint, float>>>;
    
private:
  //int model_;
  const char* param_;
};

class LinearNupackModel : public BPEngineSeq
{
public:
  LinearNupackModel(const char* param, uint beam_size=100) : param_(param), beam_size_(beam_size) {}
  void calculate_posterior(const std::string&, std::vector<float>&, std::vector<int>&) const override;
  VSVF calculate_posterior(const std::string&, float th=DEFAULT_THRESHOLD) const override;
  void calculate_posterior(const std::string&, const std::string&, std::vector<float>&, std::vector<int>&) const override;
  VSVF calculate_posterior(const std::string&, const std::string&, float th=DEFAULT_THRESHOLD) const override;
private:
  const char* param_;
  uint beam_size_;
};

class LinearPartitionModel : public BPEngineSeq
{
public:
  LinearPartitionModel(bool use_vienna=false, uint beam_size=100) : BPEngineSeq(), use_vienna_(use_vienna), beam_size_(beam_size) { }
  
  void calculate_posterior(const std::string& seq, std::vector<float>& bp, std::vector<int>& offset) const override;
  auto calculate_posterior(const std::string& seq, float th=DEFAULT_THRESHOLD) const -> std::vector<std::vector<std::pair<uint, float>>> override;
  void calculate_posterior(const std::string& seq, const std::string& paren, std::vector<float>& bp, std::vector<int>& offset) const override;
  auto calculate_posterior(const std::string& seq, const std::string& paren, float th=DEFAULT_THRESHOLD) const -> std::vector<std::vector<std::pair<uint, float>>> override;

private:
  bool use_vienna_;
  uint beam_size_;
};

class AlifoldModel : public BPEngineAln
{
public:
  AlifoldModel(const char* param);

  void calculate_posterior(const std::list<std::string>& aln, const std::string& paren,
                           std::vector<float>& bp, std::vector<int>& offset) const override;
  auto calculate_posterior(const std::list<std::string>& aln, const std::string& paren, float th=DEFAULT_THRESHOLD) const
    -> std::vector<std::vector<std::pair<uint, float>>> override;

  void calculate_posterior(const std::list<std::string>& aln,
                           std::vector<float>& bp, std::vector<int>& offset) const override;
  auto calculate_posterior(const std::list<std::string>& aln, float th=DEFAULT_THRESHOLD) const 
    -> std::vector<std::vector<std::pair<uint, float>>> override;
};

class AveragedModel : public BPEngineAln
{
public:
  AveragedModel(std::unique_ptr<BPEngineSeq>&& en) : en_(std::move(en)) { }

  void calculate_posterior(const std::list<std::string>& aln,
                           std::vector<float>& bp, std::vector<int>& offset) const override;
  auto calculate_posterior(const std::list<std::string>& aln, float th=DEFAULT_THRESHOLD) const 
    -> std::vector<std::vector<std::pair<uint, float>>> override;

  void calculate_posterior(const std::list<std::string>& aln, const std::string& paren,
                           std::vector<float>& bp, std::vector<int>& offset) const override;
  auto calculate_posterior(const std::list<std::string>& aln, const std::string& paren, float th=DEFAULT_THRESHOLD) const
    -> std::vector<std::vector<std::pair<uint, float>>> override;

private:
  std::unique_ptr<BPEngineSeq> en_;
};

class MixtureModel : public BPEngineAln
{
public:
  MixtureModel(std::vector<std::unique_ptr<BPEngineAln>>&& en)
    : en_(std::move(en)),
      w_(en_.size(), 1.0/en_.size())
  { }

  void calculate_posterior(const std::list<std::string>& aln,
                           std::vector<float>& bp, std::vector<int>& offset) const override;
  auto calculate_posterior(const std::list<std::string>& aln, float th=DEFAULT_THRESHOLD) const 
    -> std::vector<std::vector<std::pair<uint, float>>> override;

  void calculate_posterior(const std::list<std::string>& aln, const std::string& paren,
                           std::vector<float>& bp, std::vector<int>& offset) const override;
  auto calculate_posterior(const std::list<std::string>& aln, const std::string& paren, float th=DEFAULT_THRESHOLD) const
    -> std::vector<std::vector<std::pair<uint, float>>> override;

private:
  std::vector<std::unique_ptr<BPEngineAln>> en_;
  std::vector<float> w_;
};

class AuxModel
{
public:
  AuxModel() { }

  bool calculate_posterior(const char* filename, std::string& seq,
                           std::vector<float>& bp, std::vector<int>& offset) const;
  auto calculate_posterior(const char* filename, std::string& seq) const
    -> std::vector<std::vector<std::pair<uint, float>>>;
};

#endif  // __INC_FOLD_H__

// Local Variables:
// mode: C++
// End:
